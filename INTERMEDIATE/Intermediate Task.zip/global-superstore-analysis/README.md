# Global Superstore Analysis

Project folder for the Global Superstore sales performance analysis.

## Structure
- `data/raw/` — original, unmodified source data
- `data/cleaned/` — cleaned dataset produced by the analysis notebook
- `notebooks/` — Jupyter notebook containing the Python analysis
- `outputs/` — generated reports and deliverables

## Contents
- `data/raw/Global_Superstore_Raw.csv` — raw source data
- `data/cleaned/Global_Superstore_Cleaned_by_notebook.csv` — cleaned data
- `notebooks/Global_Superstore_Python_Analysis.ipynb` — analysis notebook
- `outputs/Global_Superstore_Python_Report.html` — HTML analysis report
